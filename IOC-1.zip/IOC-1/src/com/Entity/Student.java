package com.Entity;

public class Student {

	Student() {
		System.out.println("COnstructor :: Called");
	}

	public void studentDetails() {
		System.out.println("Student Details");
	}

}
